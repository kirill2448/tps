﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryD
{
    public partial class Journal : Form
    {

        public Journal()
        {
            InitializeComponent();
        }

        private void Journal_Load(object sender, EventArgs e)
        {
            journalTableAdapter1.Fill(libraryJournalDataSet1.journal);
        }

        private void СохранитьИзмененияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            journalTableAdapter1.Update(libraryJournalDataSet1.journal);
        }

        private void КнигиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Books booksForm = new Books();
            booksForm.Show();
        }

        private void ДобавитьЗаписьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddNote addNoteForm = new AddNote(this);
            addNoteForm.ShowDialog();
        }

        internal void UpdateTable()
        {
            this.journalTableAdapter1.Fill(this.libraryJournalDataSet1.journal);
        }

        private void ИзменитьЗаписьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (noteGridView.SelectedRows.Count > 0)
            {
                var selectedRow = noteGridView.SelectedRows[0];
                var originalId = Convert.ToInt32(selectedRow.Cells[0].Value);
                var originalBookCode = Convert.ToInt32(selectedRow.Cells[1].Value);
                var abonent = Convert.ToString(selectedRow.Cells[2].Value);
                var address = Convert.ToString(selectedRow.Cells[3].Value);
                var originalIssueDate = Convert.ToDateTime(selectedRow.Cells[4].Value);
                var originalReturnDate = Convert.ToDateTime(selectedRow.Cells[5].Value);
                var comment = Convert.ToString(selectedRow.Cells[6].Value);

                EditNote editNoteForm = new EditNote(this, originalId, originalBookCode, originalIssueDate, originalReturnDate, 
                                                    abonent, address, comment);
                editNoteForm.ShowDialog();
            }
        }

        private void УдалитьЗаписьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (noteGridView.SelectedRows.Count > 0)
            {
                var selectedRow = noteGridView.SelectedRows[0];
                var originalId = Convert.ToInt32(selectedRow.Cells[0].Value);
                var originalBookCode = Convert.ToInt32(selectedRow.Cells[1].Value);
                var originalIssueDate = Convert.ToDateTime(selectedRow.Cells[4].Value);
                var originalReturnDate = Convert.ToDateTime(selectedRow.Cells[5].Value);
                journalTableAdapter1.Delete(originalId, originalBookCode, originalIssueDate, originalReturnDate);
                this.journalTableAdapter1.Fill(this.libraryJournalDataSet1.journal);
            }
        }

        private void ДолжникиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Debtors debtorsForm = new Debtors();
            debtorsForm.ShowDialog();
        }
    }
}
