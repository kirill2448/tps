﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryD
{
    public partial class Books : Form
    {

        public Books()
        {
            InitializeComponent();
        }

        public void UpdateTable() {
            this.booksTableAdapter.Fill(this.libraryBooksDataSet.books);
        }

        private void Books_Load(object sender, EventArgs e)
        {
            this.booksTableAdapter.Fill(this.libraryBooksDataSet.books);
        }

        private void СохранитьИзмененияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.booksTableAdapter.Update(this.libraryBooksDataSet.books);
        }

        private void КнигиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Books booksForm = new Books();
            booksForm.Show();
        }

        private void ЖурналToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Journal journalForm = new Journal();
            journalForm.Show();
        }

        private void ДобавитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddBook addBookForm = new AddBook(this);
            addBookForm.ShowDialog();
        }

        private void ИзменитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (booksGridView.SelectedRows.Count > 0)
            {
                var selectedRow = booksGridView.SelectedRows[0];
                var originalBookCode = Convert.ToInt32(selectedRow.Cells[0].Value);
                var bookTitle = Convert.ToString(selectedRow.Cells[1].Value);
                var author = Convert.ToString(selectedRow.Cells[2].Value);
                var originalPublishDate = Convert.ToDateTime(selectedRow.Cells[3].Value);
                EditBook editBookForm = new EditBook(this, author, bookTitle, originalBookCode, originalPublishDate);
                editBookForm.ShowDialog();
            }
        }

        private void УдалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (booksGridView.SelectedRows.Count > 0)
            {
                var selectedRow = booksGridView.SelectedRows[0];
                var originalBookCode = Convert.ToInt32(selectedRow.Cells[0].Value);
                var originalPublishDate = Convert.ToDateTime(selectedRow.Cells[3].Value);
                booksTableAdapter.Delete(originalBookCode, originalPublishDate);
                this.booksTableAdapter.Fill(this.libraryBooksDataSet.books);
            }
        }

        private void ДолжникиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Debtors debtorsForm = new Debtors();
            debtorsForm.ShowDialog();
        }
    }
}
