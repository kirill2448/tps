﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryD
{
    public partial class EditBook : Form
    {
        private Books booksForm;
        private int originalBookCode;
        private DateTime originalPublishDate;

        public EditBook(Books booksForm, String author, String bookTitle, int originalBookCode, DateTime originalPublishDate)
        {
            this.booksForm = booksForm;
            this.originalBookCode = originalBookCode;
            this.originalPublishDate = originalPublishDate;
            InitializeComponent();

            authorTextBox.Text = author;
            titleTextBox.Text = bookTitle;
            publishDatePicker.Value = originalPublishDate;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            var author = authorTextBox.Text;
            var bookTitle = titleTextBox.Text;
            var publishDate = publishDatePicker.Value;
            booksTableAdapter1.Update(bookTitle, author, publishDate, originalBookCode, originalPublishDate);
            booksForm.UpdateTable();
            Close();
        }
    }
}
