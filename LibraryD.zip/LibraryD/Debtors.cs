﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryD
{
    public partial class Debtors : Form
    {
        public Debtors()
        {
            InitializeComponent();
        }

        private void Debtors_Load(object sender, EventArgs e)
        {
            debtorsGridView.Columns.Add("Debtor", "Debtor");
            debtorsGridView.Columns.Add("ReturnDate", "ReturnDate");
            debtorsGridView.Columns.Add("Debt", "Debt");

            this.journalTableAdapter1.Fill(this.libraryJournalDataSet1.journal);
            var notes = libraryJournalDataSet1.journal;
            foreach (var note in notes)
            {
                var nowDate = DateTime.Now;
                var isDebtor = note.returnDate < nowDate;
                if (isDebtor) {
                    var debt = ((nowDate - note.returnDate).TotalDays * 0.5).ToString();
                    AddDebtor(note.abonent, note.returnDate, debt);
                }
            }
        }

        private void AddDebtor(String debtor, DateTime returnDate, String debt)
        {
            DataGridViewRow newRow = new DataGridViewRow();
            newRow.CreateCells(debtorsGridView);
            newRow.Cells[0].Value = debtor;
            newRow.Cells[1].Value = returnDate;
            newRow.Cells[2].Value = debt;
            debtorsGridView.Rows.Add(newRow);
        }

    }
}
