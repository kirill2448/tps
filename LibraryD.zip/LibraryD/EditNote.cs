﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryD
{
    public partial class EditNote : Form
    {
        private Journal journalForm;
        private int originalId;
        private int originalBookCode;
        private DateTime originalIssueDate;
        private DateTime originalReturnDate;

        public EditNote(Journal journalForm, int originalId, int originalBookCode, DateTime originalIssueDate, DateTime originalReturnDate,
                        String abonent, String address, String comment)
        {
            this.journalForm = journalForm;
            this.originalId = originalId;
            this.originalBookCode = originalBookCode;
            this.originalIssueDate = originalIssueDate;
            this.originalReturnDate = originalReturnDate;
            InitializeComponent();

            bookCodeTextBox.Text = originalBookCode.ToString();
            abonentTextBox.Text = abonent;
            addressTextBox.Text = address;
            issueDatePicker.Value = originalIssueDate;
            returnDatePicker.Value = originalReturnDate;
            commentTextBox.Text = comment;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            var bookCode = Convert.ToInt32(bookCodeTextBox.Text);
            var abonent = abonentTextBox.Text;
            var address = addressTextBox.Text;
            var issueDate = issueDatePicker.Value;
            var returnDate = returnDatePicker.Value;
            var comment = commentTextBox.Text;

            journalTableAdapter1.Update(bookCode, abonent, address, issueDate, returnDate, comment, 
                                        originalId, originalBookCode, originalIssueDate, originalReturnDate);
            journalForm.UpdateTable();
            Close();
        }
    }
}
