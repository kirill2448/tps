﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryD
{
    public partial class AddBook : Form
    {
        private Books booksForm;

        public AddBook(Books booksForm)
        {
            this.booksForm = booksForm;
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            var author = this.authorTextBox.Text;
            var bookTitle = this.bookTitleTextBox.Text;
            var publishDate = publishDatePicker.Value;
            this.booksTableAdapter1.Insert(bookTitle, author, publishDate);
            booksForm.UpdateTable();
            Close();
        }
    }
}
