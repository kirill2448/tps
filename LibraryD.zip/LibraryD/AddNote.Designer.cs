﻿namespace LibraryD
{
    partial class AddNote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.issueDatePicker = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.bookCodeTextBox = new System.Windows.Forms.TextBox();
            this.abonentTextBox = new System.Windows.Forms.TextBox();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.commentTextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.journalTableAdapter1 = new LibraryD.LibraryJournalDataSetTableAdapters.journalTableAdapter();
            this.libraryJournalDataSet1 = new LibraryD.LibraryJournalDataSet();
            this.label2 = new System.Windows.Forms.Label();
            this.returnDatePicker = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.libraryJournalDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // issueDatePicker
            // 
            this.issueDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.issueDatePicker.Location = new System.Drawing.Point(163, 12);
            this.issueDatePicker.Name = "issueDatePicker";
            this.issueDatePicker.Size = new System.Drawing.Size(200, 20);
            this.issueDatePicker.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Issue date";
            // 
            // bookCodeTextBox
            // 
            this.bookCodeTextBox.Location = new System.Drawing.Point(16, 89);
            this.bookCodeTextBox.Name = "bookCodeTextBox";
            this.bookCodeTextBox.Size = new System.Drawing.Size(347, 20);
            this.bookCodeTextBox.TabIndex = 4;
            this.bookCodeTextBox.Text = "Book code";
            // 
            // abonentTextBox
            // 
            this.abonentTextBox.Location = new System.Drawing.Point(16, 116);
            this.abonentTextBox.Name = "abonentTextBox";
            this.abonentTextBox.Size = new System.Drawing.Size(347, 20);
            this.abonentTextBox.TabIndex = 5;
            this.abonentTextBox.Text = "Abonent";
            // 
            // addressTextBox
            // 
            this.addressTextBox.Location = new System.Drawing.Point(16, 143);
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(347, 20);
            this.addressTextBox.TabIndex = 6;
            this.addressTextBox.Text = "Address";
            // 
            // commentTextBox
            // 
            this.commentTextBox.Location = new System.Drawing.Point(16, 170);
            this.commentTextBox.Name = "commentTextBox";
            this.commentTextBox.Size = new System.Drawing.Size(347, 20);
            this.commentTextBox.TabIndex = 7;
            this.commentTextBox.Text = "Comment";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(287, 231);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "Add note";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // journalTableAdapter1
            // 
            this.journalTableAdapter1.ClearBeforeFill = true;
            // 
            // libraryJournalDataSet1
            // 
            this.libraryJournalDataSet1.DataSetName = "LibraryJournalDataSet";
            this.libraryJournalDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Return date";
            // 
            // returnDatePicker
            // 
            this.returnDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.returnDatePicker.Location = new System.Drawing.Point(163, 44);
            this.returnDatePicker.Name = "returnDatePicker";
            this.returnDatePicker.Size = new System.Drawing.Size(200, 20);
            this.returnDatePicker.TabIndex = 10;
            // 
            // AddNote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.returnDatePicker);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.commentTextBox);
            this.Controls.Add(this.addressTextBox);
            this.Controls.Add(this.abonentTextBox);
            this.Controls.Add(this.bookCodeTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.issueDatePicker);
            this.Name = "AddNote";
            this.Text = "AddNote";
            ((System.ComponentModel.ISupportInitialize)(this.libraryJournalDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker issueDatePicker;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox bookCodeTextBox;
        private System.Windows.Forms.TextBox abonentTextBox;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.TextBox commentTextBox;
        private System.Windows.Forms.Button button1;
        private LibraryJournalDataSetTableAdapters.journalTableAdapter journalTableAdapter1;
        private LibraryJournalDataSet libraryJournalDataSet1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker returnDatePicker;
    }
}