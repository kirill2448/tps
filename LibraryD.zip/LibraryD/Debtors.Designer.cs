﻿namespace LibraryD
{
    partial class Debtors
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.debtorsGridView = new System.Windows.Forms.DataGridView();
            this.journalTableAdapter1 = new LibraryD.LibraryJournalDataSetTableAdapters.journalTableAdapter();
            this.libraryJournalDataSet1 = new LibraryD.LibraryJournalDataSet();
            ((System.ComponentModel.ISupportInitialize)(this.debtorsGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.libraryJournalDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // debtorsGridView
            // 
            this.debtorsGridView.AllowUserToAddRows = false;
            this.debtorsGridView.AllowUserToDeleteRows = false;
            this.debtorsGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.debtorsGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.debtorsGridView.Location = new System.Drawing.Point(13, 12);
            this.debtorsGridView.MultiSelect = false;
            this.debtorsGridView.Name = "debtorsGridView";
            this.debtorsGridView.ReadOnly = true;
            this.debtorsGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.debtorsGridView.ShowEditingIcon = false;
            this.debtorsGridView.Size = new System.Drawing.Size(775, 426);
            this.debtorsGridView.TabIndex = 0;
            // 
            // journalTableAdapter1
            // 
            this.journalTableAdapter1.ClearBeforeFill = true;
            // 
            // libraryJournalDataSet1
            // 
            this.libraryJournalDataSet1.DataSetName = "LibraryJournalDataSet";
            this.libraryJournalDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Debtors
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.debtorsGridView);
            this.Name = "Debtors";
            this.Text = "Debtors";
            this.Load += new System.EventHandler(this.Debtors_Load);
            ((System.ComponentModel.ISupportInitialize)(this.debtorsGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.libraryJournalDataSet1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView debtorsGridView;
        private LibraryJournalDataSetTableAdapters.journalTableAdapter journalTableAdapter1;
        private LibraryJournalDataSet libraryJournalDataSet1;
    }
}