﻿namespace LibraryD
{
    partial class EditNote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.issueDatePicker = new System.Windows.Forms.DateTimePicker();
            this.returnDatePicker = new System.Windows.Forms.DateTimePicker();
            this.bookCodeTextBox = new System.Windows.Forms.TextBox();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.abonentTextBox = new System.Windows.Forms.TextBox();
            this.commentTextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.journalTableAdapter1 = new LibraryD.LibraryJournalDataSetTableAdapters.journalTableAdapter();
            this.libraryJournalDataSet1 = new LibraryD.LibraryJournalDataSet();
            ((System.ComponentModel.ISupportInitialize)(this.libraryJournalDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Issue date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Return date ";
            // 
            // issueDatePicker
            // 
            this.issueDatePicker.Location = new System.Drawing.Point(155, 19);
            this.issueDatePicker.Name = "issueDatePicker";
            this.issueDatePicker.Size = new System.Drawing.Size(200, 20);
            this.issueDatePicker.TabIndex = 2;
            // 
            // returnDatePicker
            // 
            this.returnDatePicker.Location = new System.Drawing.Point(155, 47);
            this.returnDatePicker.Name = "returnDatePicker";
            this.returnDatePicker.Size = new System.Drawing.Size(200, 20);
            this.returnDatePicker.TabIndex = 3;
            // 
            // bookCodeTextBox
            // 
            this.bookCodeTextBox.Location = new System.Drawing.Point(15, 107);
            this.bookCodeTextBox.Name = "bookCodeTextBox";
            this.bookCodeTextBox.Size = new System.Drawing.Size(340, 20);
            this.bookCodeTextBox.TabIndex = 4;
            this.bookCodeTextBox.Text = "Book code";
            // 
            // addressTextBox
            // 
            this.addressTextBox.Location = new System.Drawing.Point(15, 159);
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(340, 20);
            this.addressTextBox.TabIndex = 5;
            this.addressTextBox.Text = "Address";
            // 
            // abonentTextBox
            // 
            this.abonentTextBox.Location = new System.Drawing.Point(15, 134);
            this.abonentTextBox.Name = "abonentTextBox";
            this.abonentTextBox.Size = new System.Drawing.Size(340, 20);
            this.abonentTextBox.TabIndex = 6;
            this.abonentTextBox.Text = "Abonent";
            // 
            // commentTextBox
            // 
            this.commentTextBox.Location = new System.Drawing.Point(15, 186);
            this.commentTextBox.Name = "commentTextBox";
            this.commentTextBox.Size = new System.Drawing.Size(340, 20);
            this.commentTextBox.TabIndex = 7;
            this.commentTextBox.Text = "Comment";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(280, 239);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "Edit note";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // journalTableAdapter1
            // 
            this.journalTableAdapter1.ClearBeforeFill = true;
            // 
            // libraryJournalDataSet1
            // 
            this.libraryJournalDataSet1.DataSetName = "LibraryJournalDataSet";
            this.libraryJournalDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // EditNote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(367, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.commentTextBox);
            this.Controls.Add(this.abonentTextBox);
            this.Controls.Add(this.addressTextBox);
            this.Controls.Add(this.bookCodeTextBox);
            this.Controls.Add(this.returnDatePicker);
            this.Controls.Add(this.issueDatePicker);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "EditNote";
            this.Text = "EditNote";
            ((System.ComponentModel.ISupportInitialize)(this.libraryJournalDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker issueDatePicker;
        private System.Windows.Forms.DateTimePicker returnDatePicker;
        private System.Windows.Forms.TextBox bookCodeTextBox;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.TextBox abonentTextBox;
        private System.Windows.Forms.TextBox commentTextBox;
        private System.Windows.Forms.Button button1;
        private LibraryJournalDataSetTableAdapters.journalTableAdapter journalTableAdapter1;
        private LibraryJournalDataSet libraryJournalDataSet1;
    }
}