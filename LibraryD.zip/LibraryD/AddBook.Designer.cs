﻿namespace LibraryD
{
    partial class AddBook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bookTitleTextBox = new System.Windows.Forms.TextBox();
            this.authorTextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.libraryBooksDataSet1 = new LibraryD.LibraryBooksDataSet();
            this.booksTableAdapter1 = new LibraryD.LibraryBooksDataSetTableAdapters.booksTableAdapter();
            this.publishDatePicker = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.libraryBooksDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // bookTitleTextBox
            // 
            this.bookTitleTextBox.Location = new System.Drawing.Point(13, 39);
            this.bookTitleTextBox.Name = "bookTitleTextBox";
            this.bookTitleTextBox.Size = new System.Drawing.Size(100, 20);
            this.bookTitleTextBox.TabIndex = 1;
            this.bookTitleTextBox.Text = "Title";
            // 
            // authorTextBox
            // 
            this.authorTextBox.Location = new System.Drawing.Point(13, 66);
            this.authorTextBox.Name = "authorTextBox";
            this.authorTextBox.Size = new System.Drawing.Size(100, 20);
            this.authorTextBox.TabIndex = 2;
            this.authorTextBox.Text = "Author";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(118, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(326, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Добавить книгу";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // libraryBooksDataSet1
            // 
            this.libraryBooksDataSet1.DataSetName = "LibraryBooksDataSet";
            this.libraryBooksDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // booksTableAdapter1
            // 
            this.booksTableAdapter1.ClearBeforeFill = true;
            // 
            // publishDatePicker
            // 
            this.publishDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.publishDatePicker.Location = new System.Drawing.Point(12, 92);
            this.publishDatePicker.Name = "publishDatePicker";
            this.publishDatePicker.Size = new System.Drawing.Size(200, 20);
            this.publishDatePicker.TabIndex = 5;
            // 
            // AddBook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(456, 118);
            this.Controls.Add(this.publishDatePicker);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.authorTextBox);
            this.Controls.Add(this.bookTitleTextBox);
            this.Name = "AddBook";
            this.Text = "AddBook";
            ((System.ComponentModel.ISupportInitialize)(this.libraryBooksDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox bookTitleTextBox;
        private System.Windows.Forms.TextBox authorTextBox;
        private System.Windows.Forms.Button button1;
        private LibraryBooksDataSet libraryBooksDataSet1;
        private LibraryBooksDataSetTableAdapters.booksTableAdapter booksTableAdapter1;
        private System.Windows.Forms.DateTimePicker publishDatePicker;
    }
}