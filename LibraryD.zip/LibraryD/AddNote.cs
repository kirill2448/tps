﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryD
{
    public partial class AddNote : Form
    {
        private Journal journalForm;

        public AddNote(Journal journalForm)
        {
            this.journalForm = journalForm;
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            var bookCode = Convert.ToInt32(bookCodeTextBox.Text);
            var abonent = abonentTextBox.Text;
            var address = addressTextBox.Text;
            var issueDate = issueDatePicker.Value;
            var returnDate = returnDatePicker.Value;
            var comment = commentTextBox.Text;

            journalTableAdapter1.Insert(bookCode, abonent, address, issueDate, returnDate, comment);
            journalForm.UpdateTable();
            Close();
        }
    }
}
